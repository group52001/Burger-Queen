<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Burger Queen User</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  
      margin-bottom: 50px;
      border-radius: 0;
    }
    
      margin-bottom: 0;
    }
  
      background-color: #f5f5dc;
      padding: 25px;
    }
  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>E-Commerce Store for Burger Queen</h1>      
    <p>Food for the Royalties</p>
  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Burger Queen</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="#">Big Burgers</a></li>
        <li><a href="#">Combos</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="logout.php" class='btn' ><span class="glyphicon glyphicon-user"></span> Logout</a></li>
		<li><a href="#"><span class="glyphicon glyphicon-list-alt"></span> Add Product</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">    
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading">Queen's Burger</div>
        <div class="panel-body"><img src="queen.png" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer">₱ 509</div>
		<span class="glyphicon glyphicon-plus"><span class="glyphicon glyphicon-minus"></span>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading">King's Burger</div>
        <div class="panel-body"><img src="king.png" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer">₱ 389</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-success">
        <div class="panel-heading">Deluxe Burger</div>
        <div class="panel-body"><img src="Delux.png" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer">₱ 259</div>
      </div>
    </div>
  </div>
</div><br>

<div class="container">    
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading">Double Deluxe Burger</div>
        <div class="panel-body"><img src="Ddelux.png" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer">₱ 349</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading">Cheese Burger</div>
        <div class="panel-body"><img src="Cheese.png" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer">₱ 109</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading">Vegetarian Burger</div>
        <div class="panel-body"><img src="veg.png" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer">₱ 249</div>
      </div>
    </div>
  </div>
</div><br><br>

<footer class="container-fluid text-center">
  <p>This website is owned by Burger Queen Food INC. ©</p>  
  <form class="form-inline">Get amazing limited deals!:
    <input type="email" class="form-control" size="50" placeholder="Email Address">
    <button type="button" class="btn btn-danger">Sign Up!</button>
  </form>
</footer>

</body>
</html>
